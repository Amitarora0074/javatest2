package com.example.javatest2.;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    EditText user,pass;
    Button login;
    ArrayList<Member> memberList = new ArrayList<Member>();
    public static String memberName = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        fillData();

        user=findViewById(R.id.userName);
        pass=findViewById(R.id.password);
        login=findViewById(R.id.loginBtn);

        login.setOnClickListener(this);
    }
    public void fillData(){
        memberList.add(new Member(1234,"Anchal","user1", "password1"));

    }

    @Override
    public void onClick(View view) {
        String verify = verifyLogin(user.getText().toString(),pass.getText().toString());
        if(verify.isEmpty())
            Toast.makeText(getApplicationContext(),"Invalid username or password",Toast.LENGTH_LONG).show();
        else{
            memberName=verify;
            //navigate to main activity
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
        }


    }
    public String verifyLogin(String userName,String password){
        for (int i=0;i<memberList.size();i++)
            if(userName.equals(memberList.get(i).getUserName()))
                if(password.equals(memberList.get(i).getPassword()))
                    return memberList.get(i).getName();
        return null;
    }
}
